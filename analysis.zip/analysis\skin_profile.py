def build_skin_profile(
    zone_results,
    image
):
    """
    Convert SAM3 facial-zone results into
    a structured skin profile.
    """

    from .skin_features import analyze_region

    profile = {}

    for zone, results in zone_results.items():

        if len(results["masks"]) == 0:
            profile[zone] = {
                "status": "no_mask"
            }
            continue

        masks = results["masks"].cpu().numpy()

        combined_mask = masks.any(axis=0)

        features = analyze_region(
            image,
            combined_mask
        )

        profile[zone] = {
            "status": "analyzed",
            "features": features
        }

    return profile