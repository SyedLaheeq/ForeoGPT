from .skin_profile import build_skin_profile


def run_color_analysis(
    image,
    zone_results
):
    """
    Run the MVP color-analysis pipeline.

    Input:
        image       - RGB image
        zone_results - SAM3 facial-zone results

    Output:
        structured skin profile
    """

    profile = build_skin_profile(
        zone_results=zone_results,
        image=image
    )

    return {
        "status": "success",
        "analysis_type": "color",
        "zones": profile
    }